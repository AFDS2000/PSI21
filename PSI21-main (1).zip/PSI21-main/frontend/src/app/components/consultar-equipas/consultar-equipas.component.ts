import { Component } from '@angular/core';

@Component({
    selector: 'app-consultar-equipas',
    templateUrl: './consultar-equipas.component.html',
    styleUrls: ['./consultar-equipas.component.scss']
})
export class ConsultarEquipasComponent {
}
