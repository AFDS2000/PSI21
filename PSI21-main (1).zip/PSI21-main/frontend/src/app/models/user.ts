export interface User {
    _id: string;
    name: string;
    password: string;
    type: string;
}